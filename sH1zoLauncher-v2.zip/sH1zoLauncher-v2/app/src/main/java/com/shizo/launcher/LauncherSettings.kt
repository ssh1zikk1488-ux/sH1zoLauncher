package com.shizo.launcher

import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import org.json.JSONObject

private val SettingsWood = Color(0xFFB57C4A)
private val SettingsCardColor = Color(0xFF181A1D)
private val SettingsText = Color(0xFFF1F1F1)
private val SettingsSubText = Color(0xFF9AA0A6)

data class LauncherSettings(
    val language: String = "Русский",
    val ramGb: Int = 2,
    val renderer: String = "Автоматически",
    val autoFindJava: Boolean = true,
    val showExperimental: Boolean = false
)

object SettingsStore {
    private const val PREFS_NAME = "sh1zo_launcher_settings"
    private const val SETTINGS_KEY = "settings_json"

    fun load(context: Context): LauncherSettings {
        val prefs = context.getSharedPreferences(
            PREFS_NAME,
            Context.MODE_PRIVATE
        )

        val jsonString = prefs.getString(SETTINGS_KEY, null)
            ?: return LauncherSettings(
                ramGb = defaultRam(context)
            )

        return try {
            val json = JSONObject(jsonString)

            LauncherSettings(
                language = json.optString("language", "Русский"),
                ramGb = json.optInt(
                    "ramGb",
                    defaultRam(context)
                ).coerceIn(1, maxRam(context)),
                renderer = json.optString(
                    "renderer",
                    "Автоматически"
                ),
                autoFindJava = json.optBoolean(
                    "autoFindJava",
                    true
                ),
                showExperimental = json.optBoolean(
                    "showExperimental",
                    false
                )
            )
        } catch (_: Exception) {
            LauncherSettings(ramGb = defaultRam(context))
        }
    }

    fun save(
        context: Context,
        settings: LauncherSettings
    ) {
        val json = JSONObject().apply {
            put("language", settings.language)
            put("ramGb", settings.ramGb)
            put("renderer", settings.renderer)
            put("autoFindJava", settings.autoFindJava)
            put("showExperimental", settings.showExperimental)
        }

        context.getSharedPreferences(
            PREFS_NAME,
            Context.MODE_PRIVATE
        ).edit()
            .putString(SETTINGS_KEY, json.toString())
            .apply()
    }

    fun maxRam(context: Context): Int {
        val runtimeMax = Runtime.getRuntime().maxMemory()
        val runtimeGb = (runtimeMax / (1024L * 1024L * 1024L)).toInt()

        val activityManager = context.getSystemService(
            Context.ACTIVITY_SERVICE
        ) as? android.app.ActivityManager

        val memoryInfo = android.app.ActivityManager.MemoryInfo()
        activityManager?.getMemoryInfo(memoryInfo)

        val totalGb = (memoryInfo?.totalMem
            ?: (2L * 1024L * 1024L * 1024L)) /
            (1024L * 1024L * 1024L)

        // Keep a reasonable range for a mobile launcher.
        return totalGb.toInt().coerceIn(1, 8)
            .coerceAtLeast(1)
            .let { maxOf(1, minOf(it, 8)) }
    }

    fun defaultRam(context: Context): Int {
        return minOf(2, maxRam(context)).coerceAtLeast(1)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LauncherSettingsScreen(
    context: Context,
    onBack: () -> Unit
) {
    var settings by remember {
        mutableStateOf(SettingsStore.load(context))
    }

    var languageExpanded by remember { mutableStateOf(false) }
    var rendererExpanded by remember { mutableStateOf(false) }
    var showResetDialog by remember { mutableStateOf(false) }
    var showCacheInfo by remember { mutableStateOf(false) }

    val maxRam = SettingsStore.maxRam(context).coerceIn(1, 8)

    fun updateSettings(newSettings: LauncherSettings) {
        settings = newSettings
        SettingsStore.save(context, newSettings)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = "Настройки",
                    color = SettingsText
                )
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Назад",
                        tint = SettingsText
                    )
                }
            }
        )

        Text(
            text = "Настрой sH1zoLauncher под себя",
            color = SettingsSubText,
            modifier = Modifier.padding(
                start = 16.dp,
                end = 16.dp,
                bottom = 16.dp
            )
        )

        SettingsCard(
            title = "Внешний вид",
            icon = {
                Icon(
                    Icons.Default.Palette,
                    contentDescription = null,
                    tint = SettingsWood
                )
            }
        ) {
            Text(
                text = "Тема",
                color = SettingsText
            )

            Text(
                text = "Modern Wood — серый, белый и древесные оттенки",
                color = SettingsSubText,
                style = MaterialTheme.typography.bodyMedium
            )
        }

        SettingsCard(
            title = "Язык",
            icon = {
                Icon(
                    Icons.Default.Language,
                    contentDescription = null,
                    tint = SettingsWood
                )
            }
        ) {
            Text(
                text = "Язык интерфейса",
                color = SettingsText
            )

            Column {
                OutlinedButton(
                    onClick = { languageExpanded = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = SettingsText
                    )
                ) {
                    Text(settings.language)
                }

                DropdownMenu(
                    expanded = languageExpanded,
                    onDismissRequest = {
                        languageExpanded = false
                    }
                ) {
                    listOf("Русский", "English").forEach { language ->
                        DropdownMenuItem(
                            text = { Text(language) },
                            onClick = {
                                updateSettings(
                                    settings.copy(language = language)
                                )
                                languageExpanded = false
                            }
                        )
                    }
                }
            }

            Text(
                text = "Выбор сохраняется. Переключение языка во всём приложении нужно подключить отдельно.",
                color = SettingsSubText,
                style = MaterialTheme.typography.bodySmall
            )
        }

        SettingsCard(
            title = "Память",
            icon = {
                Icon(
                    Icons.Default.Memory,
                    contentDescription = null,
                    tint = SettingsWood
                )
            }
        ) {
            Text(
                text = "Выделение памяти: ${settings.ramGb} ГБ",
                color = SettingsText
            )

            if (maxRam > 1) {
                Slider(
                    value = settings.ramGb.coerceIn(1, maxRam).toFloat(),
                    onValueChange = { value ->
                        updateSettings(
                            settings.copy(
                                ramGb = value.toInt().coerceIn(1, maxRam)
                            )
                        )
                    },
                    valueRange = 1f..maxRam.toFloat(),
                    steps = (maxRam - 2).coerceAtLeast(0)
                )
            } else {
                Text(
                    text = "Доступен только минимальный вариант настройки.",
                    color = SettingsSubText
                )
            }

            Text(
                text = "Это предварительная настройка. Реальное выделение памяти заработает после подключения игрового движка.",
                color = SettingsSubText,
                style = MaterialTheme.typography.bodySmall
            )
        }

        SettingsCard(
            title = "Графика",
            icon = {
                Icon(
                    Icons.Default.Code,
                    contentDescription = null,
                    tint = SettingsWood
                )
            }
        ) {
            Text(
                text = "Графический рендерер",
                color = SettingsText
            )

            Column {
                OutlinedButton(
                    onClick = { rendererExpanded = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = SettingsText
                    )
                ) {
                    Text(settings.renderer)
                }

                DropdownMenu(
                    expanded = rendererExpanded,
                    onDismissRequest = {
                        rendererExpanded = false
                    }
                ) {
                    listOf(
                        "Автоматически",
                        "OpenGL",
                        "Vulkan"
                    ).forEach { renderer ->
                        DropdownMenuItem(
                            text = { Text(renderer) },
                            onClick = {
                                updateSettings(
                                    settings.copy(renderer = renderer)
                                )
                                rendererExpanded = false
                            }
                        )
                    }
                }
            }

            Text(
                text = "Пока сохраняется только выбор. Фактическое переключение рендерера требует подключения игрового движка.",
                color = SettingsSubText,
                style = MaterialTheme.typography.bodySmall
            )
        }

        SettingsCard(
            title = "Java",
            icon = {
                Icon(
                    Icons.Default.RestartAlt,
                    contentDescription = null,
                    tint = SettingsWood
                )
            }
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Автопоиск Java",
                        color = SettingsText
                    )

                    Text(
                        text = "Предпочтение для будущего запуска Minecraft",
                        color = SettingsSubText,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Switch(
                    checked = settings.autoFindJava,
                    onCheckedChange = { enabled ->
                        updateSettings(
                            settings.copy(autoFindJava = enabled)
                        )
                    }
                )
            }
        }

        SettingsCard(
            title = "Дополнительные параметры",
            icon = {
                Icon(
                    Icons.Default.Storage,
                    contentDescription = null,
                    tint = SettingsWood
                )
            }
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Экспериментальные функции",
                        color = SettingsText
                    )

                    Text(
                        text = "Показывать будущие тестовые возможности",
                        color = SettingsSubText,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Switch(
                    checked = settings.showExperimental,
                    onCheckedChange = { enabled ->
                        updateSettings(
                            settings.copy(showExperimental = enabled)
                        )
                    }
                )
            }
        }

        SettingsCard(
            title = "Кэш",
            icon = {
                Icon(
                    Icons.Default.Cached,
                    contentDescription = null,
                    tint = SettingsWood
                )
            }
        ) {
            Text(
                text = "Очистка кэша пока не подключена к реальным файлам лаунчера.",
                color = SettingsSubText,
                style = MaterialTheme.typography.bodyMedium
            )

            OutlinedButton(
                onClick = { showCacheInfo = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = SettingsText
                )
            ) {
                Icon(
                    Icons.Default.Cached,
                    contentDescription = null
                )
                Spacer(Modifier.width(8.dp))
                Text("Очистить кэш")
            }

            if (showCacheInfo) {
                Text(
                    text = "Очистка пока демонстрационная: файлы не удалялись.",
                    color = SettingsWood,
                    style = MaterialTheme.typography.bodySmall
                )

                OutlinedButton(
                    onClick = { showCacheInfo = false }
                ) {
                    Text("Понятно")
                }
            }
        }

        Button(
            onClick = {
                updateSettings(
                    LauncherSettings(
                        ramGb = SettingsStore.defaultRam(context)
                    )
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = SettingsWood,
                contentColor = Color.White
            )
        ) {
            Text("Сбросить настройки")
        }

        Text(
            text = "sH1zoLauncher • Minecraft Java 1.21.11",
            color = SettingsSubText,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(top = 8.dp)
        )
    }
}

@Composable
private fun SettingsCard(
    title: String,
    icon: @Composable () -> Unit,
    content: @Composable Column.() -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(
            containerColor = SettingsCardColor
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 2.dp
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                icon()
                Spacer(Modifier.width(10.dp))
                Text(
                    text = title,
                    color = SettingsText,
                    style = MaterialTheme.typography.titleMedium
                )
            }

            content()
        }
    }
}