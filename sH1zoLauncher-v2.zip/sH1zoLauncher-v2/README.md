# sH1zoLauncher

Android app (Kotlin + Jetpack Compose). UI only: tabs and screens, no game launching yet.
Build: GitHub Actions workflow publishes app-debug.apk to Releases.
