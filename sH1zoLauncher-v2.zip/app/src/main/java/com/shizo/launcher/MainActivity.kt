package com.shizo.launcher

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

object C {
    val bg = Color(0xFF0D0E10)
    val card = Color(0xFF181A1D)
    val card2 = Color(0xFF26292D)
    val wood = Color(0xFFB57C4A)
    val woodDark = Color(0xFF6A4528)
    val text = Color(0xFFF1F1F1)
    val sub = Color(0xFF9AA0A6)
    val light = Color(0xFFF1F1EE)
}

enum class Screen { Home, Builds, Profile, Versions, NewBuild, Mods, Settings, News }

data class GameBuild(val name: String, val sub: String, val thumb: Int)
data class VersionItem(val version: String, val type: String)
data class ModItem(val name: String, val desc: String, val size: String, val letter: String, val color: Color)
data class NewsItem(val title: String, val sub: String, val date: String, val thumb: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent { LauncherApp() }
    }
}

@Composable
fun LauncherApp() {
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(1900)
        splash = false
    }
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.wood,
            background = C.bg,
            surface = C.card,
            onSurface = C.text,
            onBackground = C.text
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = C.bg, contentColor = C.text) {
            if (splash) SplashScreen() else MainApp()
        }
    }
}

@Composable
fun BrandName(size: TextUnit) {
    Text(
        buildAnnotatedString {
            withStyle(SpanStyle(color = C.text)) { append("sH1zo") }
            withStyle(SpanStyle(color = C.wood)) { append("Launcher") }
        },
        fontSize = size,
        fontWeight = FontWeight.Medium
    )
}

@Composable
fun SplashScreen() {
    var start by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { start = true }
    val p by animateFloatAsState(
        targetValue = if (start) 1f else 0f,
        animationSpec = tween(1700),
        label = "load"
    )
    Box(Modifier.fillMaxSize().background(C.bg)) {
        Image(
            painterResource(R.drawable.splash_bg), null,
            Modifier.fillMaxSize(), contentScale = ContentScale.Crop
        )
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.logo_clear), null, Modifier.size(150.dp))
            Spacer(Modifier.height(14.dp))
            BrandName(32.sp)
            Spacer(Modifier.height(8.dp))
            Text("Твой мир. Твои правила.", color = C.text, fontSize = 15.sp)
        }
        Column(
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding()
                .padding(start = 56.dp, end = 56.dp, bottom = 56.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            LinearProgressIndicator(
                progress = { p },
                modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                color = C.wood,
                trackColor = C.card2
            )
            Spacer(Modifier.height(10.dp))
            Text("Загрузка...", color = C.sub, fontSize = 12.sp)
        }
    }
}

@Composable
fun MainApp() {
    val ctx = LocalContext.current
    val stack = remember { mutableStateListOf(Screen.Home) }
    val screen = stack.last()
    var selectedVersion by remember { mutableStateOf("1.21.11") }
    val builds = remember {
        mutableStateListOf(
            GameBuild("Vanilla 1.21.11", "Официальная версия", R.drawable.thumb_vanilla),
            GameBuild("Fabric 1.21.11", "Моды и оптимизация", R.drawable.thumb_fabric),
            GameBuild("Forge 1.20.1", "Популярные моды", R.drawable.thumb_forge)
        )
    }
    val mods = remember { mutableStateListOf<String>() }

    fun go(s: Screen) { stack.add(s) }
    fun tab(s: Screen) {
        stack.clear()
        stack.add(s)
    }
    fun back() { if (stack.size > 1) stack.removeAt(stack.lastIndex) }
    fun toast(t: String) { Toast.makeText(ctx, t, Toast.LENGTH_SHORT).show() }

    BackHandler(enabled = stack.size > 1) { back() }

    val isTab = screen == Screen.Home || screen == Screen.Builds || screen == Screen.Profile

    Scaffold(
        containerColor = C.bg,
        bottomBar = { if (isTab) BottomBar(screen) { tab(it) } }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when (screen) {
                Screen.Home -> HomeScreen(
                    selected = selectedVersion,
                    builds = builds,
                    onSettings = { go(Screen.Settings) },
                    onPlay = { toast("Запуск игры появится позже") },
                    onVersions = { go(Screen.Versions) },
                    onAllBuilds = { tab(Screen.Builds) },
                    onBuild = { toast("Выбрано: " + it.name) },
                    onNews = { go(Screen.News) }
                )
                Screen.Builds -> BuildsScreen(
                    builds = builds,
                    onAdd = { go(Screen.NewBuild) },
                    onBuild = { toast("Выбрано: " + it.name) }
                )
                Screen.Profile -> ProfileScreen(
                    selected = selectedVersion,
                    buildsCount = builds.size,
                    onSettings = { go(Screen.Settings) },
                    onToast = { toast(it) }
                )
                Screen.Versions -> VersionsScreen(
                    selected = selectedVersion,
                    onBack = { back() },
                    onPick = {
                        selectedVersion = it
                        toast("Версия " + it + " выбрана")
                        back()
                    }
                )
                Screen.NewBuild -> NewBuildScreen(
                    selected = selectedVersion,
                    modsCount = mods.size,
                    onBack = { back() },
                    onVersion = { go(Screen.Versions) },
                    onMods = { go(Screen.Mods) },
                    onCreate = { name, withMods ->
                        val thumb = if (withMods) R.drawable.thumb_fabric else R.drawable.thumb_vanilla
                        val sub = if (withMods) "С модами: " + mods.size else "Официальная версия"
                        builds.add(GameBuild(name + " " + selectedVersion, sub, thumb))
                        mods.clear()
                        toast("Сборка создана")
                        tab(Screen.Builds)
                    }
                )
                Screen.Mods -> ModsScreen(
                    added = mods,
                    onBack = { back() },
                    onAdd = {
                        if (mods.contains(it)) {
                            toast("Уже добавлено")
                        } else {
                            mods.add(it)
                            toast("Добавлено: " + it)
                        }
                    }
                )
                Screen.Settings -> SettingsScreen(onBack = { back() }, onToast = { toast(it) })
                Screen.News -> NewsScreen(onBack = { back() }, onToast = { toast(it) })
            }
            if (screen == Screen.Versions || screen == Screen.Profile ||
                screen == Screen.Settings || screen == Screen.News
            ) {
                Image(
                    painterResource(R.drawable.wood_corner), null,
                    Modifier.align(Alignment.BottomEnd).size(86.dp)
                )
            }
        }
    }
}

@Composable
fun BottomBar(current: Screen, onTab: (Screen) -> Unit) {
    val items = listOf(
        Triple(Screen.Home, "Главная", Icons.Default.Home),
        Triple(Screen.Builds, "Сборки", Icons.Default.Layers),
        Triple(Screen.Profile, "Профиль", Icons.Default.Person)
    )
    NavigationBar(containerColor = C.card) {
        items.forEach { (s, label, icon) ->
            NavigationBarItem(
                selected = current == s,
                onClick = { onTab(s) },
                icon = { Icon(icon, contentDescription = label) },
                label = { Text(label, fontSize = 12.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = C.text,
                    selectedTextColor = C.text,
                    unselectedIconColor = C.sub,
                    unselectedTextColor = C.sub,
                    indicatorColor = C.card2
                )
            )
        }
    }
}

// ---------- общие элементы ----------

@Composable
fun TopBar(title: String, onBack: () -> Unit, action: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Назад", tint = C.text) }
        Text(
            title, color = C.text, fontSize = 20.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f)
        )
        action()
        Spacer(Modifier.width(12.dp))
    }
}

@Composable
fun Panel(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val base = modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.card)
    Column(if (onClick != null) base.clickable(onClick = onClick) else base, content = content)
}

@Composable
fun Div() {
    HorizontalDivider(color = C.card2, modifier = Modifier.padding(horizontal = 14.dp))
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text, color = C.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 6.dp, start = 2.dp)
    )
}

@Composable
fun ImageRow(
    thumb: Int,
    title: String,
    sub: String,
    onClick: () -> Unit,
    trailing: @Composable RowScope.() -> Unit = {}
) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(C.card)
            .clickable(onClick = onClick).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painterResource(thumb), null,
            Modifier.size(width = 66.dp, height = 48.dp).clip(RoundedCornerShape(8.dp)),
            contentScale = ContentScale.Crop
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = C.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = C.sub, fontSize = 12.sp)
        }
        trailing()
    }
}

@Composable
fun BuildRow(b: GameBuild, onClick: () -> Unit) {
    ImageRow(b.thumb, b.name, b.sub, onClick) {
        Icon(Icons.Default.MoreVert, null, tint = C.sub)
        Icon(Icons.Default.ChevronRight, null, tint = C.sub)
    }
}

@Composable
fun ChipRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { o ->
            FilterChip(
                selected = o == selected,
                onClick = { onSelect(o) },
                label = { Text(o) },
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = C.card,
                    labelColor = C.text,
                    selectedContainerColor = C.light,
                    selectedLabelColor = C.bg
                )
            )
        }
    }
}

@Composable
fun InfoRow(
    label: String,
    value: String,
    leading: @Composable () -> Unit,
    trailing: @Composable () -> Unit = {}
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        leading()
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = C.sub, fontSize = 12.sp)
            Text(value, color = C.text, fontSize = 17.sp, fontWeight = FontWeight.Medium)
        }
        trailing()
    }
}

@Composable
fun LinkRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = C.text)
        Spacer(Modifier.width(14.dp))
        Text(label, color = C.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Icon(Icons.Default.ChevronRight, null, tint = C.sub)
    }
}

@Composable
fun ValueRow(label: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = C.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Text(value, color = C.sub, fontSize = 14.sp)
        Icon(Icons.Default.ChevronRight, null, tint = C.sub)
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = C.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = C.bg,
                checkedTrackColor = C.light,
                uncheckedThumbColor = C.sub,
                uncheckedTrackColor = C.card2,
                uncheckedBorderColor = C.sub
            )
        )
    }
}

// ---------- экраны ----------

@Composable
fun HomeScreen(
    selected: String,
    builds: List<GameBuild>,
    onSettings: () -> Unit,
    onPlay: () -> Unit,
    onVersions: () -> Unit,
    onAllBuilds: () -> Unit,
    onBuild: (GameBuild) -> Unit,
    onNews: () -> Unit
) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.logo_clear), null, Modifier.size(38.dp))
                Spacer(Modifier.width(10.dp))
                BrandName(21.sp)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onSettings) {
                    Icon(Icons.Default.Settings, "Настройки", tint = C.text)
                }
            }
        }
        item {
            Box(Modifier.fillMaxWidth().height(172.dp).clip(RoundedCornerShape(16.dp))) {
                Image(
                    painterResource(R.drawable.banner_home), null,
                    Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                )
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000)))
                    )
                )
                Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
                    Text("Добро пожаловать,", color = C.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Text("Игрок", color = C.text, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(2.dp))
                    Text("Готов к новым приключениям?", color = Color(0xFFD8D8D8), fontSize = 13.sp)
                }
            }
        }
        item {
            Button(
                onClick = onPlay,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = C.light, contentColor = C.bg)
            ) {
                Icon(Icons.Default.PlayArrow, null)
                Spacer(Modifier.width(6.dp))
                Text("Играть", fontSize = 17.sp, fontWeight = FontWeight.Medium)
            }
        }
        item {
            Panel(onClick = onVersions) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.grass_block), null, Modifier.size(44.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Последняя версия", color = C.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Text(selected + " · Официальная", color = C.sub, fontSize = 13.sp)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = C.sub)
                }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(top = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Layers, null, tint = C.text, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    "Мои сборки", color = C.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    "Все", color = C.wood, fontSize = 14.sp,
                    modifier = Modifier.clickable(onClick = onAllBuilds).padding(4.dp)
                )
            }
        }
        items(builds.take(3)) { b -> BuildRow(b) { onBuild(b) } }
        item {
            Panel(onClick = onNews) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Newspaper, null, tint = C.text)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        "Новости и обновления", color = C.text, fontSize = 16.sp,
                        fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f)
                    )
                    Icon(Icons.Default.ChevronRight, null, tint = C.sub)
                }
            }
        }
    }
}

@Composable
fun BuildsScreen(builds: List<GameBuild>, onAdd: () -> Unit, onBuild: (GameBuild) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Сборки", color = C.text, fontSize = 24.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onAdd) { Icon(Icons.Default.Add, "Новая сборка", tint = C.text) }
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(builds) { b -> BuildRow(b) { onBuild(b) } }
        }
    }
}

@Composable
fun Coin() {
    Box(
        Modifier.size(30.dp).clip(CircleShape).background(Color(0xFFE0A63A)),
        contentAlignment = Alignment.Center
    ) {
        Text("S", color = Color(0xFF5A3A00), fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ProfileScreen(
    selected: String,
    buildsCount: Int,
    onSettings: () -> Unit,
    onToast: (String) -> Unit
) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Box(Modifier.fillMaxWidth().height(150.dp)) {
                Image(
                    painterResource(R.drawable.profile_bg), null,
                    Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                )
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color(0x66000000), C.bg))
                    )
                )
                Row(
                    Modifier.align(Alignment.BottomStart).padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painterResource(R.drawable.avatar), null,
                        Modifier.size(62.dp).clip(CircleShape).border(2.dp, C.card2, CircleShape),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("sH1zo1kk", color = C.text, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                        Text("Игрок", color = C.sub, fontSize = 13.sp)
                    }
                    IconButton(onClick = { onToast("Редактирование профиля скоро") }) {
                        Icon(Icons.Default.Edit, null, tint = C.text)
                    }
                }
            }
        }
        item {
            Panel(Modifier.padding(horizontal = 16.dp)) {
                InfoRow("Версия игры", selected, leading = { Icon(Icons.Default.Settings, null, tint = C.text) })
                Div()
                InfoRow("Сборок установлено", buildsCount.toString(), leading = { Icon(Icons.Default.Layers, null, tint = C.text) })
            }
        }
        item {
            Panel(Modifier.padding(horizontal = 16.dp)) {
                InfoRow(
                    "Кредиты", "250",
                    leading = { Coin() },
                    trailing = {
                        Button(
                            onClick = { onToast("Пополнение скоро") },
                            colors = ButtonDefaults.buttonColors(containerColor = C.card2, contentColor = C.text),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                        ) { Text("Пополнить", fontSize = 13.sp) }
                    }
                )
                Div()
                InfoRow(
                    "Подписка", "Базовая",
                    leading = { Icon(Icons.Default.Star, null, tint = C.wood) },
                    trailing = { Text("Бесплатно", color = C.sub, fontSize = 13.sp) }
                )
            }
        }
        item {
            Panel(Modifier.padding(horizontal = 16.dp)) {
                LinkRow(Icons.Default.BarChart, "Статистика") { onToast("Статистика скоро") }
                Div()
                LinkRow(Icons.Default.Settings, "Настройки", onSettings)
                Div()
                LinkRow(Icons.Default.SupportAgent, "Поддержка") { onToast("Поддержка скоро") }
                Div()
                LinkRow(Icons.Default.ExitToApp, "Выйти") { onToast("Выход скоро") }
            }
        }
    }
}

@Composable
fun VersionsScreen(selected: String, onBack: () -> Unit, onPick: (String) -> Unit) {
    var filter by remember { mutableStateOf("Все") }
    val all = remember {
        listOf(
            VersionItem("1.21.11", "Официальные"),
            VersionItem("1.21.10", "Официальные"),
            VersionItem("1.20.6", "Официальные"),
            VersionItem("1.19.4", "Официальные"),
            VersionItem("1.18.2", "Официальные"),
            VersionItem("1.17.1", "Официальные"),
            VersionItem("1.16.5", "Официальные"),
            VersionItem("1.21.11", "Fabric"),
            VersionItem("1.20.1", "Fabric"),
            VersionItem("1.20.1", "Forge"),
            VersionItem("1.19.4", "Forge"),
            VersionItem("1.21.11", "Lite")
        )
    }
    val shown = if (filter == "Все") all else all.filter { it.type == filter }
    Column(Modifier.fillMaxSize()) {
        TopBar("Выбор версии", onBack) { Icon(Icons.Default.Search, null, tint = C.text) }
        ChipRow(listOf("Все", "Официальные", "Fabric", "Forge", "Lite"), filter) { filter = it }
        Spacer(Modifier.height(8.dp))
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(shown) { v ->
                val official = v.type == "Официальные"
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(if (v.version == selected) C.card2 else C.card)
                        .clickable { onPick(v.version) }.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(painterResource(R.drawable.grass_block), null, Modifier.size(40.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(v.version, color = C.text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                        Text(
                            if (official) "Официальная · Mojang" else v.type + " · сообщество",
                            color = C.sub, fontSize = 13.sp
                        )
                    }
                    Icon(Icons.Default.Download, null, tint = C.text)
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Default.ChevronRight, null, tint = C.sub)
                }
            }
        }
    }
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = C.text,
    unfocusedTextColor = C.text,
    focusedContainerColor = C.card,
    unfocusedContainerColor = C.card,
    focusedBorderColor = C.wood,
    unfocusedBorderColor = C.card2,
    cursorColor = C.wood
)

@Composable
fun ChoiceCard(title: String, sub: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(C.card)
            .border(1.5.dp, if (selected) C.text else Color.Transparent, shape)
            .clickable(onClick = onClick).padding(14.dp)
    ) {
        Text(title, color = C.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Text(sub, color = C.sub, fontSize = 12.sp)
    }
}

@Composable
fun NewBuildScreen(
    selected: String,
    modsCount: Int,
    onBack: () -> Unit,
    onVersion: () -> Unit,
    onMods: () -> Unit,
    onCreate: (String, Boolean) -> Unit
) {
    var name by remember { mutableStateOf("Моя сборка") }
    var withMods by remember { mutableStateOf(false) }
    var ram by remember { mutableStateOf(false) }
    var opt by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Новая сборка", onBack)
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { SectionTitle("Название сборки") }
            item {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = fieldColors()
                )
            }
            item { SectionTitle("Версия игры") }
            item {
                Panel(onClick = onVersion) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.grass_block), null, Modifier.size(32.dp))
                        Spacer(Modifier.width(12.dp))
                        Text(selected, color = C.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
                        Icon(Icons.Default.ChevronRight, null, tint = C.sub)
                    }
                }
            }
            item { SectionTitle("Тип загрузки") }
            item { ChoiceCard("Клиент", "Vanilla / Fabric / Forge", !withMods) { withMods = false } }
            item { ChoiceCard("С модами", "Выбор из каталога", withMods) { withMods = true } }
            if (withMods) {
                item { SectionTitle("Выберите моды") }
                item {
                    Panel(onClick = onMods) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Add, null, tint = C.text)
                            Spacer(Modifier.width(12.dp))
                            Text(
                                if (modsCount == 0) "Добавить моды" else "Выбрано модов: " + modsCount,
                                color = C.text, fontSize = 15.sp, modifier = Modifier.weight(1f)
                            )
                            Icon(Icons.Default.ChevronRight, null, tint = C.sub)
                        }
                    }
                }
            }
            item { SectionTitle("Дополнительно") }
            item {
                Panel {
                    SwitchRow("Выделить больше RAM", ram) { ram = it }
                    Div()
                    SwitchRow("Оптимизация", opt) { opt = it }
                }
            }
        }
        Button(
            onClick = { onCreate(name.trim().ifEmpty { "Моя сборка" }, withMods) },
            modifier = Modifier.fillMaxWidth().padding(16.dp).height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = C.light, contentColor = C.bg)
        ) { Text("Создать", fontSize = 17.sp, fontWeight = FontWeight.Medium) }
    }
}

@Composable
fun ModsScreen(added: List<String>, onBack: () -> Unit, onAdd: (String) -> Unit) {
    var tab by remember { mutableStateOf("Популярные") }
    val catalog = remember {
        listOf(
            ModItem("OptiFine", "Оптимизация графики", "2.1 MB", "OF", Color(0xFFD9541E)),
            ModItem("Sodium", "Высокая производительность", "1.8 MB", "S", Color(0xFF3FBF6B)),
            ModItem("Iris Shaders", "Шейдеры", "4.2 MB", "I", Color(0xFFB04FD0)),
            ModItem("Lithium", "Оптимизация сервера", "1.1 MB", "L", Color(0xFF6C4FD0)),
            ModItem("Xaero's Minimap", "Миникарта", "6.5 MB", "X", Color(0xFF3A7FD0)),
            ModItem("JEI", "Просмотр рецептов", "3.2 MB", "J", Color(0xFF5CA83A))
        )
    }
    val shown = if (tab == "Новые") catalog.takeLast(3) else catalog
    Column(Modifier.fillMaxSize()) {
        TopBar("Каталог модов", onBack) { Icon(Icons.Default.Search, null, tint = C.text) }
        ChipRow(listOf("Популярные", "Новые", "Все"), tab) { tab = it }
        Spacer(Modifier.height(8.dp))
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(shown) { m ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(C.card)
                        .clickable { onAdd(m.name) }.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(m.color),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(m.letter, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(m.name, color = C.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Text(m.desc, color = C.sub, fontSize = 12.sp)
                        Text(m.size, color = C.sub, fontSize = 12.sp)
                    }
                    Icon(
                        if (added.contains(m.name)) Icons.Default.Check else Icons.Default.Download,
                        null, tint = C.text
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit, onToast: (String) -> Unit) {
    var smooth by remember { mutableStateOf(true) }
    var touch by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Настройки", onBack)
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { SectionTitle("Графика") }
            item {
                Panel {
                    ValueRow("Режим отображения", "Классический") { onToast("Скоро") }
                    Div()
                    ValueRow("Лимит FPS", "Без ограничений") { onToast("Скоро") }
                    Div()
                    SwitchRow("Плавная анимация", smooth) { smooth = it }
                    Div()
                    ValueRow("Графика", "Высокая") { onToast("Скоро") }
                }
            }
            item { SectionTitle("Управление") }
            item {
                Panel {
                    ValueRow("Размер кнопок", "Стандартный") { onToast("Скоро") }
                    Div()
                    SwitchRow("Сенсорное управление", touch) { touch = it }
                }
            }
            item { SectionTitle("Прочее") }
            item {
                Panel {
                    ValueRow("Язык", "Русский") { onToast("Скоро") }
                    Div()
                    ValueRow("Очистить кэш", "1.2 GB") { onToast("Кэш очищен") }
                }
            }
            item {
                Button(
                    onClick = { onToast("Настройки сброшены") },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp).height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = C.wood, contentColor = C.text)
                ) { Text("Сбросить настройки", fontSize = 15.sp, fontWeight = FontWeight.Medium) }
            }
        }
    }
}

@Composable
fun NewsScreen(onBack: () -> Unit, onToast: (String) -> Unit) {
    val items = remember {
        listOf(
            NewsItem("Топ 5 лучших модов", "Для комфортного выживания.", "18.10.2026", R.drawable.thumb_news1),
            NewsItem("Гайд по шейдерам", "Как установить и настроить.", "15.10.2026", R.drawable.thumb_news2),
            NewsItem("Релиз Fabric 1.21.11", "Улучшенная производительность.", "12.10.2026", R.drawable.thumb_news3)
        )
    }
    Column(Modifier.fillMaxSize()) {
        TopBar("Новости", onBack)
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Box(
                    Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(16.dp))
                        .clickable { onToast("Minecraft 1.21.11") }
                ) {
                    Image(
                        painterResource(R.drawable.news_hero), null,
                        Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                    )
                    Box(
                        Modifier.fillMaxSize().background(
                            Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000)))
                        )
                    )
                    Column(Modifier.align(Alignment.BottomStart).padding(14.dp)) {
                        Box(
                            Modifier.clip(RoundedCornerShape(6.dp)).background(C.light)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) { Text("Обновление", color = C.bg, fontSize = 11.sp, fontWeight = FontWeight.Medium) }
                        Spacer(Modifier.height(6.dp))
                        Text("Minecraft 1.21.11", color = C.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                        Text("Новые функции, исправления и улучшения.", color = Color(0xFFD8D8D8), fontSize = 13.sp)
                        Text("20.10.2026", color = C.sub, fontSize = 11.sp)
                    }
                }
            }
            items(items) { n ->
                ImageRow(
                    n.thumb, n.title, n.sub + "\n" + n.date,
                    onClick = { onToast(n.title) },
                    trailing = { Icon(Icons.Default.ChevronRight, null, tint = C.sub) }
                )
            }
        }
    }
}
