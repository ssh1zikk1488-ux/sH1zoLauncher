# sH1zoLauncher — Android prototype

Native Android project using Kotlin + Jetpack Compose. No HTML and no game launch implementation.

## Included
- Home, Builds, Profile tabs
- Version picker demo for Minecraft Java 1.21.11
- Settings and sample mod catalog screens
- User-provided logo asset
- GitHub Actions workflow to build a debug APK

## Build an APK without a computer
1. Create a GitHub repository. From a phone: upload this whole .zip file to the repo root (it is unpacked during the build) and add the workflow file .github/workflows/build-apk.yml. From a PC: upload the unpacked folder.
2. Open the repository's **Actions** tab.
3. Select **Build sH1zoLauncher APK** and press **Run workflow** (or push to `main`).
4. Open the completed workflow run and download the `sH1zoLauncher-debug-apk` artifact.
5. Extract the ZIP and install `app-debug.apk` on Android. You may need to allow installation from your browser/files app.

This is an early interface prototype. Version/mod cards are demo data; downloads, account sync, and Minecraft launching are intentionally not implemented.
