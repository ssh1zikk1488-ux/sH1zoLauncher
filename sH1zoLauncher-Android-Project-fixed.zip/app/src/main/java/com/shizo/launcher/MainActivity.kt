package com.shizo.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B0D0E)
private val Panel = Color(0xFF1A1E20)
private val Panel2 = Color(0xFF24292B)
private val Wood = Color(0xFFC08A5A)
private val TextMain = Color(0xFFF4F2ED)
private val TextMuted = Color(0xFF9DA3A4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent { LauncherApp() }
    }
}

@Composable
fun LauncherApp() {
    var tab by remember { mutableStateOf("Главная") }
    var detail by remember { mutableStateOf<String?>(null) }
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Wood,
            onBackground = TextMain, onSurface = TextMain, onPrimary = Bg
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            BackHandler(enabled = detail != null) { detail = null }
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                if (detail != null) {
                    DetailScreen(detail!!, onBack = { detail = null })
                } else {
                    Box(Modifier.weight(1f)) {
                        when (tab) {
                            "Главная" -> HomeScreen(
                                onVersions = { detail = "Выбор версии" },
                                onBuilds = { tab = "Сборки" },
                                onNews = { detail = "Новости" },
                                onSettings = { detail = "Настройки" }
                            )
                            "Сборки" -> BuildsScreen(
                                onNew = { detail = "Новая сборка" },
                                onOpen = { detail = it }
                            )
                            else -> ProfileScreen(onOpen = { detail = it })
                        }
                    }
                    NavigationBar(containerColor = Color(0xFF111416), tonalElevation = 0.dp) {
                        listOf(
                            Triple("Главная", Icons.Default.Home, "home"),
                            Triple("Сборки", Icons.Default.Layers, "layers"),
                            Triple("Профиль", Icons.Default.Person, "person")
                        ).forEach { (label, icon, _) ->
                            NavigationBarItem(
                                selected = tab == label,
                                onClick = { tab = label },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label, fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Wood,
                                    selectedTextColor = TextMain,
                                    indicatorColor = Panel2,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ScreenTitle(title: String, subtitle: String? = null) {
    Column(Modifier.padding(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 12.dp)) {
        Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = TextMain)
        if (subtitle != null) Text(subtitle, color = TextMuted, fontSize = 13.sp)
    }
}

@Composable
fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp)
            .background(Panel, RoundedCornerShape(16.dp)).padding(14.dp),
        content = content
    )
}

@Composable
fun HomeScreen(onVersions: () -> Unit, onBuilds: () -> Unit, onNews: () -> Unit, onSettings: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(painterResource(R.drawable.launcher_logo), null, Modifier.size(42.dp))
                Spacer(Modifier.width(10.dp))
                Text("sH1zo", fontWeight = FontWeight.Bold, fontSize = 21.sp)
                Text("Launcher", color = Wood, fontWeight = FontWeight.Bold, fontSize = 21.sp)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Настройки") }
            }
        }
        item {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp)
                    .background(Panel2, RoundedCornerShape(18.dp)).padding(18.dp)
            ) {
                Text("ТВОЙ МИР. ТВОИ ПРАВИЛА.", color = Wood, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Готов к новым\nприключениям?", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Minecraft Java Edition · 1.21.11", color = TextMuted, fontSize = 13.sp)
            }
        }
        item {
            Button(
                onClick = { /* Запуск игры намеренно не реализован в этой версии */ },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp).height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = TextMain, contentColor = Bg),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Construction, null)
                Spacer(Modifier.width(8.dp))
                Text("Запуск игры пока отключён", fontWeight = FontWeight.SemiBold)
            }
        }
        item {
            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { onVersions() }) {
                    Text("🟩", fontSize = 25.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Последняя версия", fontWeight = FontWeight.SemiBold)
                        Text("1.21.11 · Официальная", color = TextMuted, fontSize = 12.sp)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
                }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Layers, null, tint = Wood)
                Spacer(Modifier.width(8.dp))
                Text("Мои сборки", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onBuilds) { Text("Все", color = Wood) }
            }
        }
        items(listOf("Vanilla 1.21.11" to "Официальная версия", "Fabric 1.21.11" to "Моды и оптимизация", "Forge 1.20.1" to "Популярные моды")) { build ->
            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).background(Panel2, RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Terrain, null, tint = Wood, modifier = Modifier.size(28.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(build.first, fontWeight = FontWeight.Medium)
                        Text(build.second, color = TextMuted, fontSize = 12.sp)
                    }
                    IconButton(onClick = onBuilds) { Icon(Icons.Default.ChevronRight, null, tint = TextMuted) }
                }
            }
        }
        item {
            CardBox {
                Row(Modifier.fillMaxWidth().clickable { onNews() }, verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Newspaper, null, tint = Wood)
                    Spacer(Modifier.width(10.dp))
                    Text("Новости и обновления", Modifier.weight(1f))
                    Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
                }
            }
        }
        item { Spacer(Modifier.height(12.dp)) }
    }
}

@Composable
fun BuildsScreen(onNew: () -> Unit, onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Сборки", "Твои игровые профили")
        LazyColumn(Modifier.weight(1f)) {
            items(listOf("Vanilla 1.21.11", "Fabric 1.21.11", "Forge 1.20.1")) { name ->
                CardBox {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ViewInAr, null, tint = Wood, modifier = Modifier.size(34.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(name, fontWeight = FontWeight.SemiBold)
                            Text("Только карточка-пример · не установлена", color = TextMuted, fontSize = 11.sp)
                        }
                        IconButton(onClick = { onOpen(name) }) { Icon(Icons.Default.ChevronRight, null) }
                    }
                }
            }
        }
        Button(
            onClick = onNew,
            modifier = Modifier.fillMaxWidth().padding(14.dp).height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = TextMain, contentColor = Bg),
            shape = RoundedCornerShape(14.dp)
        ) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Создать сборку") }
    }
}

@Composable
fun ProfileScreen(onOpen: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        item { ScreenTitle("Профиль", "Настройки твоего лаунчера") }
        item {
            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AccountCircle, null, tint = Wood, modifier = Modifier.size(54.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("sH1zo1kk", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text("Локальный профиль", color = TextMuted, fontSize = 12.sp)
                    }
                }
            }
        }
        items(listOf("Статистика", "Настройки", "Поддержка", "О приложении")) { label ->
            CardBox {
                Row(Modifier.fillMaxWidth().clickable { onOpen(label) }, verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        when (label) {
                            "Статистика" -> Icons.Default.BarChart
                            "Настройки" -> Icons.Default.Settings
                            "Поддержка" -> Icons.Default.SupportAgent
                            else -> Icons.Default.Info
                        }, null, tint = Wood
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(label, Modifier.weight(1f))
                    Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
                }
            }
        }
    }
}

@Composable
fun DetailScreen(title: String, onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf("Все") }
    var toggle by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize().navigationBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Назад") }
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (title == "Выбор версии" || title == "Каталог модов") {
                IconButton(onClick = { query = if (query.isEmpty()) "1.21" else "" }) {
                    Icon(Icons.Default.Search, "Поиск")
                }
            }
        }
        when (title) {
            "Выбор версии" -> {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Все", "Официальные", "Fabric", "Forge", "Lite").forEach {
                        FilterChip(selected = selected == it, onClick = { selected = it }, label = { Text(it, fontSize = 11.sp) })
                    }
                }
                LazyColumn {
                    items(listOf("1.21.11", "1.21.10", "1.20.6", "1.19.4", "1.18.2", "1.17.1", "1.16.5").filter { it.contains(query) }) { version ->
                        CardBox {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Terrain, null, tint = Wood, modifier = Modifier.size(30.dp))
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(version, fontWeight = FontWeight.SemiBold)
                                    Text(if (selected == "Все") "Официальная · Mojang" else selected, color = TextMuted, fontSize = 12.sp)
                                }
                                Icon(Icons.Default.Download, null, tint = TextMuted)
                            }
                        }
                    }
                }
            }
            "Настройки" -> {
                LazyColumn {
                    item { SectionLabel("Внешний вид") }
                    item { SettingRow("Тема", "Тёмная", onClick = { selected = if (selected == "Тёмная") "Системная" else "Тёмная" }) }
                    item { SettingRow("Акцент", "Древесный", onClick = { selected = if (selected == "Древесный") "Графитовый" else "Древесный" }) }
                    item { SectionLabel("Поведение") }
                    item {
                        CardBox {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Плавная анимация", Modifier.weight(1f))
                                Switch(checked = toggle, onCheckedChange = { toggle = it })
                            }
                        }
                    }
                    item { SettingRow("Версия Minecraft", "1.21.11", onClick = { }) }
                    item { SectionLabel("Хранилище") }
                    item { SettingRow("Очистить кэш", "Пока недоступно", onClick = { selected = "Кэш можно будет очистить в следующей версии" }) }
                    if (selected.startsWith("Кэш")) item { Text(selected, Modifier.padding(16.dp), color = TextMuted) }
                }
            }
            "Новая сборка" -> {
                var name by remember { mutableStateOf("Моя сборка") }
                var created by remember { mutableStateOf(false) }
                Column(Modifier.padding(14.dp)) {
                    Text("Название сборки", color = TextMuted)
                    OutlinedTextField(value = name, onValueChange = { name = it }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Spacer(Modifier.height(14.dp))
                    Text("Версия игры", color = TextMuted)
                    SettingRow("Minecraft Java", "1.21.11", onClick = {})
                    Spacer(Modifier.height(12.dp))
                    Text("Тип загрузчика", color = TextMuted)
                    listOf("Vanilla", "Fabric", "Forge").forEach { option ->
                        FilterChip(selected = selected == option, onClick = { selected = option }, label = { Text(option) })
                    }
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = { created = true }, modifier = Modifier.fillMaxWidth()) { Text("Создать") }
                    if (created) Text("Черновик «$name» создан в интерфейсе. Установка игры пока не выполняется.", color = Wood)
                }
            }
            "Каталог модов" -> {
                LazyColumn {
                    items(listOf("Sodium", "Iris Shaders", "Lithium", "Xaero's Minimap", "JEI").filter { it.contains(query, true) }) { mod ->
                        CardBox {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Extension, null, tint = Wood)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(mod)
                                    Text("Демонстрационная карточка", color = TextMuted, fontSize = 12.sp)
                                }
                                Icon(Icons.Default.Download, null, tint = TextMuted)
                            }
                        }
                    }
                }
            }
            else -> {
                CardBox {
                    Text(
                        when (title) {
                            "Новости" -> "Здесь появятся новости Minecraft и обновления лаунчера."
                            "Статистика" -> "Пока нет игровых данных: запуск Minecraft ещё не подключён."
                            "Поддержка" -> "Раздел поддержки будет подключён на следующем этапе."
                            "О приложении" -> "sH1zoLauncher 0.1.0\nИнтерфейсный прототип для Minecraft Java 1.21.11."
                            else -> "$title\nЭтот раздел пока работает в демонстрационном режиме."
                        },
                        lineHeight = 23.sp
                    )
                }
                if (title == "Новая сборка") Unit
                if (title == "Сборки" || title == "Vanilla 1.21.11" || title == "Fabric 1.21.11" || title == "Forge 1.20.1") {
                    CardBox { Text("Управление сборками будет расширено позже.", color = TextMuted) }
                }
            }
        }
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(text, Modifier.padding(start = 18.dp, top = 16.dp, bottom = 4.dp), color = Wood, fontWeight = FontWeight.Bold)
}

@Composable
fun SettingRow(title: String, value: String, onClick: () -> Unit) {
    CardBox {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(title)
                Text(value, color = TextMuted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
        }
    }
}
